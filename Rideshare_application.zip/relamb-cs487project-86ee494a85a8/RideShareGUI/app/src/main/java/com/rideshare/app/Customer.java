package com.rideshare.app;

import java.io.Serializable;

public class Customer implements Serializable {
    private String name;
    private String email;
    private String phoneNum;
    private String cardNum;
    private String password;
    private String location;
    private String destination;

    public Customer(String name, String email, String phoneNum, String cardNum, String password){
        this.name = name;
        this.email = email;
        this.phoneNum = phoneNum;
        this.cardNum = cardNum;
        this.password = password;
        this.location = null;
        this.destination = null;
    }

    public Customer(String name, String email, String phoneNum, String cardNum, String password, String location, String destination){
        this.name = name;
        this.email = email;
        this.phoneNum = phoneNum;
        this.cardNum = cardNum;
        this.password = password;
        this.location = location;
        this.destination = destination;
    }
    public String getName(){
        return this.name;
    }
    public String getEmail(){
        return this.email;
    }
    public String getPhoneNum(){
        return this.phoneNum;
    }
    public String getCardNum(){
        return this.cardNum;
    }
    public String getPassword(){
        return this.password;
    }
    public String getLocation(){
        return this.location;
    }
    public String getDestination(){
        return this.destination;
    }
    public void setName(String name){
        this.name = name;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public void setPhoneNum(String phoneNum){
        this.phoneNum = phoneNum;
    }
    public void setCardNum(String cardNum){
        this.cardNum = cardNum;
    }
    public void setPassword(String password){
        this.password = password;
    }
    public void setLocation(String location){
        this.location = location;
    }
    public void setDestination(String destination){
        this.destination = destination;
    }
}

