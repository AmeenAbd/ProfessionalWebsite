package com.rideshare.app;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.rideshare.app.customer.CustomerRegister;
import com.rideshare.app.customer.CustomersMainPage;
import com.rideshare.app.customer.RequestRide;
import com.rideshare.app.driver.DriverMainPage;
import com.rideshare.app.driver.DriverRegisterActivity;
import com.rideshare.app.driver.DriverStatus;
import org.w3c.dom.Text;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    TextView textView_customerAccount;
    TextView textView_driverAccount;
    private static final int REGISTER_REQUEST_CODE = 1;
    private DatabaseHandler databaseHandler;
    private EditText email;
    private EditText password;
    private TextView invalidText;
    Button login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        databaseHandler = new DatabaseHandler(this);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        invalidText = findViewById(R.id.invalidText);
        invalidText.setText("");
        textView_customerAccount=findViewById(R.id.cust_have_account);
        textView_driverAccount=findViewById(R.id.drive_have_account);
        login = findViewById(R.id.register);
        login.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v){ if(databaseHandler.validLogin(email.getText().toString(), password.getText().toString())){
            invalidText.setText("correct username and password");
            Intent intent;
            if(databaseHandler.isCustomer(email.getText().toString()))
            {
                intent= new Intent(MainActivity.this, CustomersMainPage.class);
            }
            else{
                intent= new Intent(MainActivity.this, DriverMainPage.class);
            }
            intent.putExtra("EMAIL", email.getText().toString());
            startActivity(intent);
        }
        else {
            invalidText.setText("invalid username or password");
        }
        }});
        textView_customerAccount.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v){ Intent intent= new Intent(MainActivity.this, CustomerRegister.class);
            startActivityForResult(intent, REGISTER_REQUEST_CODE);}});
        textView_driverAccount.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v){ Intent intent= new Intent(MainActivity.this, DriverRegisterActivity.class);
            startActivityForResult(intent, REGISTER_REQUEST_CODE);}});
    }
 /*   public void clickRegister(View v){
        Intent intent= new Intent(MainActivity.this, CustomerRegister.class);
       // startActivity(intent);
        startActivityForResult(intent, REGISTER_REQUEST_CODE);
    } */
   /* public void clickLogin(View v){
        if(databaseHandler.validLogin(email.getText().toString(), password.getText().toString())){
            invalidText.setText("correct username and password");
        }
        else{
            invalidText.setText("invalid username or password");
        }
    } */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REGISTER_REQUEST_CODE){           if(resultCode == RESULT_OK) {
            if (data.hasExtra("CUSTOMER")) {
                Customer customer = (Customer) data.getSerializableExtra("CUSTOMER");
                databaseHandler.addCustomer(customer);
                return;
            }
            else if(data.hasExtra("DRIVER")){
                Driver driver = (Driver) data.getSerializableExtra("DRIVER");
                databaseHandler.addDriver(driver);
                return;
            }
        }
        }
    }
}
