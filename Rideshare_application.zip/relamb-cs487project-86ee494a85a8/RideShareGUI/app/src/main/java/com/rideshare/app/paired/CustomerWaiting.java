package com.rideshare.app.paired;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.rideshare.app.DatabaseHandler;
import com.rideshare.app.R;
import com.rideshare.app.Ride;
import com.rideshare.app.customer.CustomersMainPage;
import com.rideshare.app.customer.RequestRide;
import com.rideshare.app.customer.UpdateCustomerInformation;

public class CustomerWaiting extends AppCompatActivity {
    String cust_message;
    String drive_message;
    String cust_email;
    String drive_email;
    DatabaseHandler databaseHandler;
    private TextView customerMessage;
    Button confirm;
    Button cancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_waiting);
        Intent retrievedIntent = this.getIntent();
        cust_message = (String) retrievedIntent.getSerializableExtra("CUST_MESSAGE");
        drive_message = (String) retrievedIntent.getSerializableExtra("DRIVE_MESSAGE");
        cust_email = (String) retrievedIntent.getSerializableExtra("CUST_EMAIL");
        drive_email = (String) retrievedIntent.getSerializableExtra("DRIVE_EMAIL");
        databaseHandler = new DatabaseHandler(this);
        customerMessage = findViewById(R.id.cust_message);
        confirm = findViewById(R.id.confirm);
        cancel = findViewById(R.id.cancel);
        customerMessage.setText(cust_message);
        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO: Send customer information to paired driver main screen
            }
        });
        //If ride is canceled, update status of ride to be "CANCELLED"
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                customerMessage.setText("RIDE CANCELLED");
                Intent intent = new Intent(CustomerWaiting.this, RequestRide.class);
                Ride currentRide = databaseHandler.findRideInProgress(cust_email,drive_email);
                databaseHandler.updateRide(currentRide,null,null,null,null,"CANCELED");
                startActivity(intent);
            }
        });
    }
}