package com.rideshare.app.driver;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.android.material.textfield.TextInputEditText;
import com.rideshare.app.Customer;
import com.rideshare.app.DatabaseHandler;
import com.rideshare.app.Driver;
import com.rideshare.app.MainActivity;
import com.rideshare.app.R;
import com.rideshare.app.driver.DriverRegisterActivity;
import java.util.Objects;

public class DriverRegisterActivity extends AppCompatActivity {
    Button submit;
    private EditText nameText;
    private EditText emailText;
    private EditText phoneNumText;
    private EditText cardNumText;
    private EditText passwordText;
    private EditText vehicleInfoText;
  //  String email;
  //  DatabaseHandler databaseHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_register);
     //   Intent retrievedIntent = this.getIntent();
      //  email = (String) retrievedIntent.getSerializableExtra("EMAIL");
     //   databaseHandler = new DatabaseHandler(this);
     //   Driver currentDriver = databaseHandler.getDriver(email);
        //change the action bar
        Objects.requireNonNull(getSupportActionBar()).setTitle("Driver Registration ");
        //set Home as Enabled       getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        nameText = findViewById(R.id.driver_name);
        emailText = findViewById(R.id.driver_email);
        phoneNumText = findViewById(R.id.phoneNumber);
        cardNumText = findViewById(R.id.creditNumber);
        passwordText = findViewById(R.id.password);
        vehicleInfoText = findViewById(R.id.vehicle_info);
        submit = (Button)findViewById(R.id.register);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Go back to main screen
                Intent intent= new Intent(DriverRegisterActivity.this, MainActivity.class);
                Driver driver = new Driver(nameText.getText().toString(), emailText.getText().toString(), phoneNumText.getText().toString(), cardNumText.getText().toString(), passwordText.getText().toString(), vehicleInfoText.getText().toString());
                intent.putExtra("DRIVER", driver);
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }
}