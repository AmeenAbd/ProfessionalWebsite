package com.rideshare.app.driver;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.rideshare.app.Customer;
import com.rideshare.app.DatabaseHandler;
import com.rideshare.app.Driver;
import com.rideshare.app.R;
import com.rideshare.app.customer.CustomersMainPage;
import com.rideshare.app.customer.RequestRide;
import com.rideshare.app.customer.UpdateCustomerInformation;

public class DriverMainPage extends AppCompatActivity {
    Button activateDriver;
    Button update;
    private static final int REGISTER_REQUEST_CODE = 3;
    String email;
    private DatabaseHandler databaseHandler;
    private EditText locationText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_main_page);
        Intent retrievedIntent = this.getIntent();
        email = (String) retrievedIntent.getSerializableExtra("EMAIL");
        databaseHandler = new DatabaseHandler(this);
        Driver currentDriver = databaseHandler.getDriver(email);
        locationText = findViewById(R.id.driver_location);
      /*  if(currentDriver.getLocation()!=null){
            locationText.setText(currentDriver.getLocation());
        } */
        /*Initialization*/
        activateDriver =(Button)findViewById(R.id.activate_button);
        update = (Button)findViewById(R.id.update_info);
        activateDriver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(currentDriver.getStatus().compareTo("INACTIVE")==0)
                {
                    currentDriver.setLocation(locationText.getText().toString());
                    currentDriver.setStatus("ACTIVE");
                    databaseHandler.updateDriverStatus(currentDriver);
                    databaseHandler.updateDriverLocation(currentDriver);
                    activateDriver.setText("Set Inactive");
                    Intent requestRide = new Intent(DriverMainPage.this, RequestRide.class);
                    requestRide.putExtra("EMAIL", email);
                    startActivity(requestRide);
                }
                else if(currentDriver.getStatus().compareTo("ACTIVE")==0)
                {
                    currentDriver.setStatus("INACTIVE");
                    databaseHandler.updateDriverStatus(currentDriver);
                    activateDriver.setText("Set Active");
                }

            }
        });
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DriverMainPage.this, UpdateDriverInformation.class);
                intent.putExtra("EMAIL",email);
                startActivityForResult(intent, REGISTER_REQUEST_CODE);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REGISTER_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                if (data.hasExtra("DRIVER")) {
                    Driver driver = (Driver) data.getSerializableExtra("DRIVER");
                    driver.setEmail(email);
                    databaseHandler.updateDriver(driver);
                    return;
                }
            }
        }
    }
}