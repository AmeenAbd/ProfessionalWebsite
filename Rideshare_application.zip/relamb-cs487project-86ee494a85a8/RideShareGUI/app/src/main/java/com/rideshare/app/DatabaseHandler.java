package com.rideshare.app;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHandler extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "RideShareDB";
    private static final String TABLE_NAME_CUSTOMER = "CustomerTable";
    private static final String TABLE_NAME_DRIVER = "DriverTable";
    private static final String TABLE_NAME_RIDE = "RideTable";
    private static final String NAME = "Name";
    private static final String EMAIL = "Email";
    private static final String PHONE_NUM = "PhoneNumber";
    private static final String CARD_NUM = "CardNumber";
    private static final String PASSWORD = "Password";
    private static final String LOCATION = "Location";
    private static final String DESTINATION = "Destination";
    private static final String VEHICLE_INFO = "VehicleInfo";
    private static final String STATUS = "Status";
    private static final String CUST_EMAIL = "CustomerEmail";
    private static final String DRIVE_EMAIL = "DriverEmail";
    private static final String PASSENGERS = "Passengers";
    private static final String COST = "Cost";

    private final SQLiteDatabase database; //Changed this to public

    private static final String SQL_CREATE_TABLE_CUSTOMER =
            "CREATE TABLE " + TABLE_NAME_CUSTOMER + " (" +
                    NAME + " TEXT not null, " +
                    EMAIL + " TEXT not null unique, " +
                    PHONE_NUM + " TEXT not null, " +
                    CARD_NUM + " TEXT not null, " +
                    PASSWORD + " TEXT not null, " +
                    LOCATION + " TEXT, " +
                    DESTINATION + " TEXT)";
    private static final String SQL_CREATE_TABLE_DRIVER =
            "CREATE TABLE " + TABLE_NAME_DRIVER + " (" +
                    NAME + " TEXT not null, " +
                    EMAIL + " TEXT not null unique, " +
                    PHONE_NUM + " TEXT not null, " +
                    CARD_NUM + " TEXT not null, " +
                    PASSWORD + " TEXT not null, " +
                    VEHICLE_INFO + " TEXT not null, " +
                    LOCATION + " TEXT, " +
                    STATUS+ " TEXT)";
    private static final String SQL_CREATE_TABLE_RIDE =
            "CREATE TABLE " + TABLE_NAME_RIDE + " (" +
                    CUST_EMAIL + " TEXT not null, " +
                    DRIVE_EMAIL + " TEXT not null, " +
                    PASSENGERS + " TEXT not null, " +
                    COST + " TEXT not null, " +
                    LOCATION + " TEXT not null, " +
                    DESTINATION + " TEXT not null, " +
                    STATUS+ " TEXT not null)";
    public DatabaseHandler(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        database = getWritableDatabase();
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_TABLE_CUSTOMER);
        db.execSQL(SQL_CREATE_TABLE_DRIVER);
        db.execSQL(SQL_CREATE_TABLE_RIDE);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }
    public void addCustomer(Customer customer){
        ContentValues values = new ContentValues();
        values.put(NAME, customer.getName());
        values.put(EMAIL, customer.getEmail());
        values.put(PHONE_NUM, customer.getPhoneNum());
        values.put(CARD_NUM, customer.getCardNum());
        values.put(PASSWORD, customer.getPassword());
        database.insert(TABLE_NAME_CUSTOMER, null, values);
    }

    public void updateCustomer(Customer customer){
        ContentValues values = new ContentValues();
        if(customer.getName().compareTo("")!=0)
        {
            values.put(NAME, customer.getName());
        }
        if(customer.getPhoneNum().compareTo("")!=0)
        {
            values.put(PHONE_NUM, customer.getPhoneNum());
        }
        if(customer.getCardNum().compareTo("")!=0)
        {
            values.put(CARD_NUM, customer.getCardNum());
        }
        if(customer.getPassword().compareTo("")!=0)
        {
            values.put(PASSWORD, customer.getPassword());
        }
        String[] mail = {customer.getEmail()};
        database.update(TABLE_NAME_CUSTOMER,values, "EMAIL = ?",mail);
    }

    public void updateCustomerLocation(Customer customer){
        ContentValues values = new ContentValues();
        values.put(LOCATION, customer.getLocation());
        String[] mail = {customer.getEmail()};
        database.update(TABLE_NAME_CUSTOMER,values, "EMAIL = ?",mail);
    }

    public void updateCustomerDestination(Customer customer){
        ContentValues values = new ContentValues();
        values.put(DESTINATION, customer.getDestination());
        String[] mail = {customer.getEmail()};
        database.update(TABLE_NAME_CUSTOMER,values, "EMAIL = ?",mail);
    }

    public void updateDriver(Driver driver){
        ContentValues values = new ContentValues();
        if(driver.getName().compareTo("")!=0)
        {
            values.put(NAME, driver.getName());
        }
        if(driver.getPhoneNum().compareTo("")!=0)
        {
            values.put(PHONE_NUM, driver.getPhoneNum());
        }
        if(driver.getCardNum().compareTo("")!=0)
        {
            values.put(CARD_NUM, driver.getCardNum());
        }
        if(driver.getPassword().compareTo("")!=0)
        {
            values.put(PASSWORD, driver.getPassword());
        }
        if(driver.getVehicleInfo().compareTo("")!=0)
        {
            values.put(VEHICLE_INFO, driver.getVehicleInfo());
        }
        String[] mail = {driver.getEmail()};
        database.update(TABLE_NAME_DRIVER,values, "EMAIL = ?",mail);
    }

    public void updateDriverStatus(Driver driver){
        ContentValues values = new ContentValues();
        values.put(STATUS, driver.getStatus());
        String[] mail = {driver.getEmail()};
        database.update(TABLE_NAME_DRIVER,values, "EMAIL = ?",mail);
    }

    public void updateDriverLocation(Driver driver){
        ContentValues values = new ContentValues();
        values.put(LOCATION, driver.getLocation());
        String[] mail = {driver.getEmail()};
        database.update(TABLE_NAME_DRIVER,values, "EMAIL = ?",mail);
    }

    public void addDriver(Driver driver){
        ContentValues values = new ContentValues();
        values.put(NAME, driver.getName());
        values.put(EMAIL, driver.getEmail());
        values.put(PHONE_NUM, driver.getPhoneNum());
        values.put(CARD_NUM, driver.getCardNum());
        values.put(PASSWORD, driver.getPassword());
        values.put(VEHICLE_INFO,driver.getVehicleInfo());
        values.put(STATUS, driver.getStatus());
        database.insert(TABLE_NAME_DRIVER, null, values);
    }

    public void addRide(Ride ride){
        ContentValues values = new ContentValues();
        Customer customer = ride.getCustomer();
        Driver driver = ride.getDriver();
        values.put(CUST_EMAIL, customer.getEmail());
        values.put(DRIVE_EMAIL, driver.getEmail());
        values.put(PASSENGERS, ride.getNumPassengers());
        values.put(COST, ride.getCost());
        values.put(LOCATION, ride.getStartLocation());
        values.put(DESTINATION,ride.getDestination());
        values.put(STATUS, ride.getStatus());
        database.insert(TABLE_NAME_RIDE, null, values);
    }

    public void updateRide(Ride ride, String passengers, String cost, String startLocation, String destination, String status)
    {
        ContentValues values = new ContentValues();
        Customer currentCustomer = ride.getCustomer();
        Driver currentDriver = ride.getDriver();
        if(passengers!=null)
        {
            values.put(PASSENGERS, passengers);
        }
        if(cost!=null)
        {
            values.put(COST, cost);
        }
        if(startLocation!=null)
        {
            values.put(LOCATION, startLocation);
        }
        if(destination!=null)
        {
            values.put(DESTINATION, destination);
        }
        if(status!=null)
        {
            values.put(STATUS, status);
        }
        String[] data = {currentCustomer.getEmail(),currentDriver.getEmail(),"IN PROGRESS"};
        database.update(TABLE_NAME_RIDE,values, "CUSTOMEREMAIL = ? AND DRIVEREMAIL = ? AND STATUS = ? ",data);
    }



    public boolean validLogin(String email, String password){
        Cursor cursor = database.query(
                TABLE_NAME_CUSTOMER, // The table to query
                new String[]{EMAIL, PASSWORD},
                null,
                null,
                null,
                null,
                null);
        if(cursor != null){
            cursor.moveToFirst();
            for(int i = 0; i < cursor.getCount(); i++){
                String e = cursor.getString(0);
                String p = cursor.getString(1);
                if(email.equals(e) && password.equals(p)){
                    return true;
                }
                cursor.moveToNext();
            }
            cursor.close();
        }
        cursor = database.query(
                TABLE_NAME_DRIVER, // The table to query
                new String[]{EMAIL, PASSWORD},
                null,
                null,
                null,
                null,
                null);
        if(cursor != null){
            cursor.moveToFirst();
            for(int i = 0; i < cursor.getCount(); i++){
                String e = cursor.getString(0);
                String p = cursor.getString(1);
                if(email.equals(e) && password.equals(p)){
                    return true;
                }
                cursor.moveToNext();
            }
            cursor.close();
        }
        return false;
    }

    public boolean isCustomer(String email) {
        Cursor cursor = database.query(
                TABLE_NAME_CUSTOMER, // The table to query
                new String[]{EMAIL},
                null,
                null,
                null,
                null,
                null);
        if (cursor != null) {
            cursor.moveToFirst();
            for (int i = 0; i < cursor.getCount(); i++) {
                String e = cursor.getString(0);
                if (email.equals(e)) {
                    return true;
                }
                cursor.moveToNext();
            }
            cursor.close();
        }
        return false;
    }

    public Customer getCustomer(String email) {
        Cursor cursor = database.query(
                TABLE_NAME_CUSTOMER, // The table to query
                new String[]{NAME,EMAIL,PHONE_NUM,CARD_NUM,PASSWORD,LOCATION,DESTINATION},
                null,
                null,
                null,
                null,
                null);
        if (cursor != null) {
            cursor.moveToFirst();
            for (int i = 0; i < cursor.getCount(); i++) {
                String e = cursor.getString(1);
                if (email.equals(e)) {
                    //int columns = cursor.getColumnCount();
                    Customer newCustomer = new Customer("","","","","","","");
                    newCustomer.setName(cursor.getString(0));
                    newCustomer.setEmail(cursor.getString(1));
                    newCustomer.setPhoneNum(cursor.getString(2));
                    newCustomer.setCardNum(cursor.getString(3));
                    newCustomer.setPassword(cursor.getString(4));
                    newCustomer.setLocation(cursor.getString(5));
                    newCustomer.setDestination(cursor.getString(6));
                    return newCustomer;
                }
                cursor.moveToNext();
            }
            cursor.close();
        }
        return null;
    }

    public Driver getDriver(String email) {
        Cursor cursor = database.query(
                TABLE_NAME_DRIVER, // The table to query
                new String[]{NAME,EMAIL,PHONE_NUM,CARD_NUM,PASSWORD,VEHICLE_INFO,LOCATION,STATUS},
                null,
                null,
                null,
                null,
                null);
        if (cursor != null) {
            cursor.moveToFirst();
            for (int i = 0; i < cursor.getCount(); i++) {
                String e = cursor.getString(1);
                if (email.equals(e)) {
                    //int columns = cursor.getColumnCount();
                    Driver newDriver = new Driver("","","","","","","");
                    newDriver.setName(cursor.getString(0));
                    newDriver.setEmail(cursor.getString(1));
                    newDriver.setPhoneNum(cursor.getString(2));
                    newDriver.setCardNum(cursor.getString(3));
                    newDriver.setPassword(cursor.getString(4));
                    newDriver.setVehicleInfo(cursor.getString(5));
                    newDriver.setLocation(cursor.getString(6));
                    newDriver.setStatus(cursor.getString(7));
                    return newDriver;
                }
                cursor.moveToNext();
            }
            cursor.close();
        }
        return null;
    }

    public Driver findDriverPair()
    {
        Cursor cursor = database.query(
                TABLE_NAME_DRIVER, // The table to query
                new String[]{NAME,EMAIL,PHONE_NUM,CARD_NUM,PASSWORD,VEHICLE_INFO,LOCATION,STATUS},
                null,
                null,
                null,
                null,
                null);
        if (cursor != null) {
            cursor.moveToFirst();
            for (int i = 0; i < cursor.getCount(); i++) {
                String e = cursor.getString(7);
                if (e.compareTo("ACTIVE")==0) {
                    //int columns = cursor.getColumnCount();
                    Driver newDriver = new Driver("","","","","","","");
                    newDriver.setName(cursor.getString(0));
                    newDriver.setEmail(cursor.getString(1));
                    newDriver.setPhoneNum(cursor.getString(2));
                    newDriver.setCardNum(cursor.getString(3));
                    newDriver.setPassword(cursor.getString(4));
                    newDriver.setVehicleInfo(cursor.getString(5));
                    newDriver.setLocation(cursor.getString(6));
                    newDriver.setStatus(cursor.getString(7));
                    return newDriver;
                }
                cursor.moveToNext();
            }
            cursor.close();
        }
        System.out.println("No Drivers Are Available!");
        return null;
    }

    public Ride findRideInProgress(String customerEmail, String driverEmail )
    {
        Cursor cursor = database.query(
                TABLE_NAME_RIDE, // The table to query
                new String[]{CUST_EMAIL,DRIVE_EMAIL,COST,STATUS},
                null,
                null,
                null,
                null,
                null);
        if (cursor != null) {
            cursor.moveToFirst();
            for (int i = 0; i < cursor.getCount(); i++) {
                String cEmail = cursor.getString(0);
                String dEmail = cursor.getString(1);
                String status = cursor.getString(3);
                if (cEmail.compareTo(customerEmail)==0 && dEmail.compareTo(driverEmail)==0 && status.compareTo("IN PROGRESS")==0) {
                    Customer customer = getCustomer(cEmail);
                    Driver driver = getDriver(dEmail);
                    Ride newRide = new Ride(customer,driver,"IN PROGRESS","","$20.00",customer.getLocation(), customer.getDestination());
                    newRide.setCost(cursor.getString(2));
                    return newRide;
                }
                cursor.moveToNext();
            }
            cursor.close();
        }
        System.out.println("No Current Rides in Progress");
        return null;
    }
}

