package com.rideshare.app.customer;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import com.rideshare.app.Customer;
import com.rideshare.app.DatabaseHandler;
import com.rideshare.app.Driver;
import com.rideshare.app.R;
import com.rideshare.app.Ride;
import com.rideshare.app.paired.CustomerWaiting;

public class RequestRide extends AppCompatActivity {

    /*Variables declaration*/
    Spinner spinner;
    String email;
    Ride custRide;
    Button buttonRequestRide;
    DatabaseHandler databaseHandler;
    private EditText passengers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_ride);

        //Views Initialization
        spinner = findViewById(R.id.spinner);
        Intent retrievedIntent = this.getIntent();
        email = (String) retrievedIntent.getSerializableExtra("EMAIL");
        passengers = findViewById(R.id.passengers);
        databaseHandler = new DatabaseHandler(this);
        Customer currentCustomer = databaseHandler.getCustomer(email);
        String[] rideclass = {"Standard","XL","Luxury"};
        //Creating the ArrayAdapter instance having the country list
        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, rideclass);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        spinner.setAdapter(aa);
        buttonRequestRide = (Button)findViewById(R.id.request);
        buttonRequestRide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Driver pairedDriver = databaseHandler.findDriverPair();
                Intent requestRide = new Intent(RequestRide.this, CustomerWaiting.class);
             /*   if(pairedDriver == null)
                {
                    requestRide = new Intent(RequestRide.this, RequestRide.class);
                    requestRide.putExtra("EMAIL", email);
                    startActivity(requestRide);
                }
                else
                {
                    requestRide = new Intent(RequestRide.this, CustomerWaiting.class);
                } */
                //Set driver inactive
                pairedDriver.setStatus("INACTIVE");
                databaseHandler.updateDriverStatus(pairedDriver);
                //Create Ride and add to database
                custRide = new Ride(currentCustomer,pairedDriver,"IN PROGRESS",passengers.getText().toString(),"$20.00",currentCustomer.getLocation(),currentCustomer.getDestination());
                databaseHandler.addRide(custRide);
                String custMessage = custRide.getDriverInfo();
                String driveMessage = custRide.getCustomerInfo();
                requestRide.putExtra("CUST_MESSAGE", custMessage);
                requestRide.putExtra("DRIVE_MESSAGE", driveMessage);
                requestRide.putExtra("CUST_EMAIL",email);
                requestRide.putExtra("DRIVE_EMAIL",pairedDriver.getEmail());
                startActivity(requestRide);
            }
        });



    }
}