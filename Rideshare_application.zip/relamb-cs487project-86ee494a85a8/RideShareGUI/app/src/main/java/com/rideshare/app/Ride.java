package com.rideshare.app;

import java.io.Serializable;

public class Ride implements Serializable{
    private Customer customer;
    private Driver driver;
    private String status;
    private String numPassengers;
    private String cost;
    private String start_location;
    private String destination;

    public Ride(Customer customer, Driver driver, String status, String numPassengers, String cost, String start_location, String destination){
        this.customer = customer;
        this.driver = driver;
        this.status = status;
        this.numPassengers = numPassengers;
        this.cost = cost;
        this.start_location = start_location;
        this.destination = destination;
    }

    public Customer getCustomer(){
        return this.customer;
    }
    public Driver getDriver(){
        return this.driver;
    }
    public String getStatus(){
        return this.status;
    }
    public String getNumPassengers(){
        return this.numPassengers;
    }
    public String getCost(){
        return this.cost;
    }
    public String getStartLocation(){
        return this.start_location;
    }
    public String getDestination(){
        return this.destination;
    }

    public void setStatus(String status){
        this.status = status;
    }
    public void setNumPassengers(String numPassengers){
        this.numPassengers = numPassengers;
    }
    public void setCost(String cost){
        this.cost = cost;
    }
    public void setStartLocation(String start_location){
        this.start_location = start_location;
    }
    public void setDestination(String destination){
        this.destination = destination;
    }

    public String getCustomerInfo()
    {
        Customer currentCustomer = this.getCustomer();
        String message = "Customer: "+currentCustomer.getName()+" Location: "+currentCustomer.getLocation()+" Destination: "+currentCustomer.getDestination()+
               " Passengers: "+this.getNumPassengers()+ " Rating: 5.0/5.0";
        return message;
    }

    public String getDriverInfo()
    {
        Driver currentDriver = this.getDriver();
        String message = "Driver: "+currentDriver.getName()+" Location: "+currentDriver.getLocation()+" Vehicle: "+currentDriver.getVehicleInfo()+
               " Est. Cost: "+ this.getCost()+" License Plate: TESTLICENSE "+ "Rating: 5.0/5.0";
        return message;
    }
}
