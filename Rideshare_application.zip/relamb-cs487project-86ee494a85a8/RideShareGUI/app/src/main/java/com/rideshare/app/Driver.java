package com.rideshare.app;

import java.io.Serializable;

public class Driver implements Serializable {
    private String name;
    private String email;
    private String phoneNum;
    private String cardNum;
    private String password;
    private String vehicleInfo;
    private String location;
    private String status;

    public Driver(String name, String email, String phoneNum, String cardNum, String password, String vehicleInfo){
        this.name = name;
        this.email = email;
        this.phoneNum = phoneNum;
        this.cardNum = cardNum;
        this.password = password;
        this.vehicleInfo = vehicleInfo;
        this.location = null;
        this.status = "INACTIVE";
    }

    public Driver(String name, String email, String phoneNum, String cardNum, String password, String vehicleInfo, String location){
        this.name = name;
        this.email = email;
        this.phoneNum = phoneNum;
        this.cardNum = cardNum;
        this.password = password;
        this.vehicleInfo = vehicleInfo;
        this.location = location;
        this.status = "INACTIVE";
    }
    public String getName(){
        return this.name;
    }
    public String getEmail(){
        return this.email;
    }
    public String getPhoneNum(){
        return this.phoneNum;
    }
    public String getCardNum(){
        return this.cardNum;
    }
    public String getPassword(){
        return this.password;
    }
    public String getVehicleInfo(){
        return this.vehicleInfo;
    }
    public String getLocation(){
        return this.location;
    }
    public String getStatus(){
        return this.status;
    }
    public void setName(String name){
        this.name = name;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public void setPhoneNum(String phoneNum){
        this.phoneNum = phoneNum;
    }
    public void setCardNum(String cardNum){
        this.cardNum = cardNum;
    }
    public void setPassword(String password){
        this.password = password;
    }
    public void setVehicleInfo(String vehicleInfo){
        this.vehicleInfo = vehicleInfo;
    }
    public void setLocation(String location){
        this.location = location;
    }
    public void setStatus(String status){
        this.status = status;
    }
}
