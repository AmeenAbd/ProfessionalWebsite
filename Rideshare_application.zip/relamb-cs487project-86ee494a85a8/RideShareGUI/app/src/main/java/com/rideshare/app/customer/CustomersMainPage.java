package com.rideshare.app.customer;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.rideshare.app.Customer;
import com.rideshare.app.DatabaseHandler;
import com.rideshare.app.Driver;
import com.rideshare.app.R;

public class CustomersMainPage extends AppCompatActivity {

    Button buttonRequestRide;
    Button update;
    private static final int REGISTER_REQUEST_CODE = 2;
    String email;
    //private static final int REGISTER_REQUEST_CODE_DRIVER = 2;
    private DatabaseHandler databaseHandler;
    private EditText locationText;
    private EditText destinationText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customers_main_page);
        Intent retrievedIntent = this.getIntent();
        email = (String) retrievedIntent.getSerializableExtra("EMAIL");
        databaseHandler = new DatabaseHandler(this);
        Customer currentCustomer = databaseHandler.getCustomer(email);
        locationText = findViewById(R.id.customer_location);
        destinationText = findViewById(R.id.customer_destination);
        //emailText = findViewById(R.id.customer_email);
      /*  if(currentCustomer.getLocation()!=null){
            locationText.setText(currentCustomer.getLocation());
        }
        if(currentCustomer.getDestination()!=null){
            destinationText.setText(currentCustomer.getDestination());
        } */
        /*Initialization*/
        buttonRequestRide =(Button)findViewById(R.id.next);
        update = (Button)findViewById(R.id.update_info);
        buttonRequestRide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentCustomer.setLocation(locationText.getText().toString());
                currentCustomer.setDestination(destinationText.getText().toString());
                databaseHandler.updateCustomerLocation(currentCustomer);
                databaseHandler.updateCustomerDestination(currentCustomer);
                Intent requestRide = new Intent(CustomersMainPage.this,RequestRide.class);
                requestRide.putExtra("EMAIL", email);
                startActivity(requestRide);
            }
        });
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CustomersMainPage.this,UpdateCustomerInformation.class);
                intent.putExtra("EMAIL",email);
                startActivityForResult(intent, REGISTER_REQUEST_CODE);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REGISTER_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                if (data.hasExtra("CUSTOMER")) {
                    Customer customer = (Customer) data.getSerializableExtra("CUSTOMER");
                    customer.setEmail(email);
                    databaseHandler.updateCustomer(customer);
                    return;
                }
                if (data.hasExtra("DRIVER")) {
                    Driver driver = (Driver) data.getSerializableExtra("DRIVER");
                    driver.setEmail(email);
                    databaseHandler.updateDriver(driver);
                    return;
                }
            }
        }
    }
}