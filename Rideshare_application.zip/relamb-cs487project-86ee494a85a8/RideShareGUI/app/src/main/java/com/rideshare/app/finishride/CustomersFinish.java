package com.rideshare.app.finishride;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.rideshare.app.R;

public class CustomersFinish extends AppCompatActivity {

    Spinner rate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customers_finish);

        //Views Initialization
        rate = findViewById(R.id.spinner_rate);
        String[] rideclass = {"1", "2", "3", "4", "5"};
        //Creating the ArrayAdapter instance having the country list
        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, rideclass);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        rate.setAdapter(aa);
    }
}