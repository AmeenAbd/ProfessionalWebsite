package com.rideshare.app.driver;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.rideshare.app.R;

public class DriverStatus extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_status);
    }
}